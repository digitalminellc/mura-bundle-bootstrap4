# templates/components

Any files you add here can be used to wrap any Component in a template. This can be useful for isolating markup from non-technical users. For instance, adding wrapping div's with specific CSS hooks you want to make sure don't get deleted in the WYSIWYG editor. You can also use this to pass in JavaScript, CSS, etc.
