module.exports = require('./src/scripts/theme');
