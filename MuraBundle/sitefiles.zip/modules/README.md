# Site Modules

This is where you can put Mura CMS modules that are only accessible to this site. In previous versions of Mura CMS modules were referred to as "display objects".

You can copy core modules (https://github.com/blueriver/MuraCMS/tree/7.1/core/modules/v1) here to makes site customizations or add new modules.
